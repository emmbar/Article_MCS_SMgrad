###################################
#Import
###################################

import sys
import numpy as np
from netCDF4 import Dataset
import numpy.ma as ma
import matplotlib.pyplot as plt
from matplotlib import cm
plt.switch_backend('agg')
import copy
from scipy import stats
import matplotlib.gridspec as gridspec

###################################################

regions = ['WAf','Ind','SAf','SAm']

Tgrad_favourable = []
Tgrad_unfavourable = []
Hgrad_favourable = []
Hgrad_unfavourable = []

for region in regions:
	
	data = Dataset('composites/'+region+'_anom_evo.nc')

	Tgrad_F = data['Tgrad_anom_F'][:]
        Tgrad_U = data['Tgrad_anom_U'][:]
        Hgrad_F = data['Hgrad_anom_F'][:]
        Hgrad_U = data['Hgrad_anom_U'][:]

	Tgrad_favourable.append(Tgrad_F)
        Tgrad_unfavourable.append(Tgrad_U)
        Hgrad_favourable.append(Hgrad_F)
        Hgrad_unfavourable.append(Hgrad_U)


hour = []

for i in range(-134,0):
	hour.append(i)


################################################

#f=plt.figure(constrained_layout=True)
f=plt.figure(figsize=(10,5))

#spec = gridspec.GridSpec(ncols=6, nrows=2, figure=f)

#a1 = f.add_subplot(spec[0,0:3])
a1 = f.add_subplot(2,2,1)

plt.axvspan(-41,-17,color='lightgray',alpha=0.4)

a1.bar(hour,Hgrad_favourable[0],width=0.5,color='b',alpha=0.6)
a1.bar(hour,Hgrad_unfavourable[0],width=0.5,color='orange',alpha=0.6)

a1b  = a1.twinx()

a1b.plot(hour,Tgrad_favourable[0],'-',color='b',label='favourable')
a1b.plot(hour,Tgrad_unfavourable[0],'-',color='orange',label='unfavourable')

plt.axvline(-24,color='k')

a1.set_title('WAf', weight='bold',size='large')

a1.set_xticks([-120,-96,-72,-48,-24,0])
a1.set_xticklabels([])

a1.set_ylim(-5.5,5.5)
a1b.set_ylim(-0.2,0.2)

plt.text(-30,0.21,'storm')

a1.set_xlim(-134,0)

#a1.set_xlabel('Hours relative to storm time (1700 LT)')
a1.set_ylabel(r'HAgrad')
#a1b.set_ylabel('Tgrad anom [k]',size='large')

a1.tick_params(axis='both', which='major', labelsize=11)
a1b.tick_params(axis='both', which='major', labelsize=11)

#a2 = f.add_subplot(spec[0,3:6])
a2 = f.add_subplot(2,2,2)

plt.axvspan(-41,-17,color='lightgray',alpha=0.4)

a2.bar(hour,Hgrad_favourable[1],width=0.5,color='b',alpha=0.6)
a2.bar(hour,Hgrad_unfavourable[1],width=0.5,color='orange',alpha=0.6)

a2b  = a2.twinx()

a2b.plot(hour,Tgrad_favourable[1],'-',color='b',label='favourable')
a2b.plot(hour,Tgrad_unfavourable[1],'-',color='orange',label='unfavourable')

plt.axvline(-24,color='k')

a2.set_title('Ind', weight='bold',size='large')

a2.set_xticks([-120,-96,-72,-48,-24,0])
a2.set_xticklabels([])

a2.set_ylim(-5,11)
a2b.set_ylim(-0.2,0.4)

a2.set_xlim(-134,0)

#a2.set_xlabel('Hours relative to storm time (1700 LT)',size='large')
#a2.set_ylabel(r'Hgrad anom [Wm$^{-2}$]',size='large')
a2b.set_ylabel('TAgrad')

a2.tick_params(axis='both', which='major', labelsize=11)
a2b.tick_params(axis='both', which='major', labelsize=11)

plt.text(-30,0.41,'storm')

#a3 = f.add_subplot(spec[1,0:3])
a3 = f.add_subplot(2,2,3)

plt.axvspan(-41,-17,color='lightgray',alpha=0.4)

a3.bar(hour,Hgrad_favourable[2],width=0.5,color='b',alpha=0.6)
a3.bar(hour,Hgrad_unfavourable[2],width=0.5,color='orange',alpha=0.6)

a3b  = a3.twinx()

a3b.plot(hour,Tgrad_favourable[2],'-',color='b',label='favourable')
a3b.plot(hour,Tgrad_unfavourable[2],'-',color='orange',label='unfavourable')

plt.axvline(-24,color='k')

a3.set_title('SAf', weight='bold',size='large')

a3.set_xticks([-120,-96,-72,-48,-24,0])
a3.set_xticklabels(['-96','-72','-48','-24','0','+24'])

a3.set_ylim(-16,6)
a3b.set_ylim(-0.6,0.4)

a3.set_xlim(-134,0)

a3.set_xlabel('Hours relative to storm time (1700 LT)')
a3.set_ylabel(r'HAgrad')
#a3b.set_ylabel('Tgrad anom [k]',size='large')

a3.tick_params(axis='both', which='major', labelsize=11)
a3b.tick_params(axis='both', which='major', labelsize=11)

plt.text(-30,0.42,'storm')

#a4 = f.add_subplot(spec[1,3:6])
a4 = f.add_subplot(2,2,4)

plt.axvspan(-41,-17,color='lightgray',alpha=0.4)

a4.bar(hour,Hgrad_favourable[3],width=0.5,color='b',alpha=0.6,label='favourable HAgrad')
a4.bar(hour,Hgrad_unfavourable[3],width=0.5,color='orange',alpha=0.6,label='unfavourable HAgrad')

a4b  = a4.twinx()

a4b.plot(hour,Tgrad_favourable[3],'-',color='b',label='favourable TAgrad')
a4b.plot(hour,Tgrad_unfavourable[3],'-',color='orange',label='unfavourable TAgrad')

plt.axvline(-24,color='k')

a4.set_title('SAm', weight='bold',size='large')

a4.set_xticks([-120,-96,-72,-48,-24,0])
a4.set_xticklabels(['-96','-72','-48','-24','0','+24'])

a4.set_ylim(-20,13)
a4b.set_ylim(-0.7,0.7)

a4.set_xlim(-134,0)

plt.text(-30,0.72,'storm')

#a4.set_xlabel('Hours relative to storm time (1700 LT)',size='large')
#a4.set_ylabel(r'Hgrad anom [Wm$^{-2}$]',size='large')
a4b.set_ylabel('TAgrad')

a4.tick_params(axis='both', which='major', labelsize=11)
a4b.tick_params(axis='both', which='major', labelsize=11)

a4.legend(loc='upper right', bbox_to_anchor=(1.8, 1.5))
a4b.legend(loc='upper right', bbox_to_anchor=(1.8, 1.2))

plt.subplots_adjust(wspace=0.3, hspace=0.2)

plt.savefig('figure3b.jpeg',dpi=1000,bbox_inches='tight',pad_inches=0.1)





