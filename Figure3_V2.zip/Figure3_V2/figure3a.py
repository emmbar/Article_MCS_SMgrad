###################################
#Import
###################################

import sys
import numpy as np
from netCDF4 import Dataset
import scipy.ndimage.interpolation as inter
from scipy.interpolate import griddata
import numpy.ma as ma
import matplotlib.pyplot as plt
from matplotlib import cm
plt.switch_backend('agg')
import copy
from scipy.spatial.qhull import QhullError
from scipy import stats
import matplotlib.gridspec as gridspec

###################################################

regions = ['WAf', 'Ind', 'SAf', 'SAm']

area_favourable_SMAP = []
rain_favourable_SMAP = []
area_unfavourable_SMAP = []
rain_unfavourable_SMAP = []

for region in regions:
	data = Dataset('dist/'+region+'_PF1_char_dist_SMAP.nc')
	areaF = data['area_F_percentiles'][:]
	areaU = data['area_U_percentiles'][:]
	rainF = data['rain_tot_F_percentiles'][:]
	rainU = data['rain_tot_U_percentiles'][:]
	area_favourable_SMAP.append(areaF)
        area_unfavourable_SMAP.append(areaU)
	rain_favourable_SMAP.append(rainF)
	rain_unfavourable_SMAP.append(rainU)

area_favourable_ASCAT = []
rain_favourable_ASCAT = []
area_unfavourable_ASCAT = []
rain_unfavourable_ASCAT = []

for region in regions:
	data = Dataset('dist/'+region+'_PF1_char_dist_ASCAT.nc')
	areaF = data['area_F_percentiles'][:]
	areaU = data['area_U_percentiles'][:]
	rainF = data['rain_tot_F_percentiles'][:]
	rainU = data['rain_tot_U_percentiles'][:]
	area_favourable_ASCAT.append(areaF)
        area_unfavourable_ASCAT.append(areaU)
	rain_favourable_ASCAT.append(rainF)
	rain_unfavourable_ASCAT.append(rainU)	

###########################################################

f=plt.figure()
a1 = f.add_subplot(2,4,1)

a1.plot(area_unfavourable_ASCAT[0],area_favourable_ASCAT[0],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a1.plot(area_unfavourable_SMAP[0],area_favourable_SMAP[0],color='r',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a1.get_xlim(), a1.get_ylim()]), np.max([a1.get_xlim(), a1.get_ylim()]),]

a1.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a1.set_aspect(0.9)
a1.set_title('WAf',loc='left',weight='bold')
a1.set_xlim(lims)
a1.set_ylim(lims)
a1.set_xticks([0,25,50])
a1.set_yticks([0,22,44])
a1.set_ylabel('favourable Area')
a1.set_xlabel('unfavourable Area')


a2 = f.add_subplot(2,4,2)

a2.plot(area_unfavourable_ASCAT[1],area_favourable_ASCAT[1],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a2.plot(area_unfavourable_SMAP[1],area_favourable_SMAP[1],color='r',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a2.get_xlim(), a2.get_ylim()]), np.max([a2.get_xlim(), a2.get_ylim()]),]

a2.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a2.set_aspect(0.9)
a2.set_title('Ind',loc='left',weight='bold')
#a2.set_ylabel('favourable Area')
#a2.set_xlabel('unfavourable Area')
a2.set_xlim(lims)
a2.set_ylim(lims)
a2.set_xticks([0,27,54])
a2.set_yticks([0,27,54])

a3 = f.add_subplot(2,4,3)

a3.plot(area_unfavourable_ASCAT[2],area_favourable_ASCAT[2],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a3.plot(area_unfavourable_SMAP[2],area_favourable_SMAP[2],color='r',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a3.get_xlim(), a3.get_ylim()]), np.max([a3.get_xlim(), a3.get_ylim()]),]

a3.plot(lims, lims, 'k-', linewidth=0.8,zorder=0)

a3.set_aspect(0.9)
a3.set_title('SAf',loc='left',weight='bold')
#a3.set_ylabel('favourable Area')
#a3.set_xlabel('unfavourable Area')
a3.set_xlim(lims)
a3.set_ylim(lims)
a3.set_xticks([0,27,54])
a3.set_yticks([0,27,54])

a4 = f.add_subplot(2,4,4)

a4.plot(area_unfavourable_ASCAT[3],area_favourable_ASCAT[3],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a4.plot(area_unfavourable_SMAP[3],area_favourable_SMAP[3],color='r',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a4.get_xlim(), a4.get_ylim()]), np.max([a4.get_xlim(), a4.get_ylim()]),]

a4.plot(lims, lims, 'k-', linewidth=0.8,zorder=0)

a4.legend(loc='upper right', bbox_to_anchor=(2.1, 1))

a4.set_aspect(0.9)
a4.set_title('SAm',loc='left',weight='bold')
#a4.set_ylabel('favourable Area')
#a4.set_xlabel('unfavourable Area')
a4.set_xlim(lims)
a4.set_ylim(lims)
a4.set_xticks([0,50,100])
a4.set_yticks([0,50,100])


###########################################################################################

a5= f.add_subplot(2,4,5)

a5.plot(rain_unfavourable_ASCAT[0],rain_favourable_ASCAT[0],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a5.plot(rain_unfavourable_SMAP[0],rain_favourable_SMAP[0],color='blue',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a5.get_xlim(), a5.get_ylim()]), np.max([a5.get_xlim(), a5.get_ylim()]),]

a5.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a5.set_aspect(0.9)
#a5.set_title('WAf',loc='left',weight='bold',pad=-14)
a5.set_xlim(lims)
a5.set_ylim(lims)
a5.set_ylabel(r'favourable rain$_{tot}$')
a5.set_xlabel(r'unfavourable rain$_{tot}$')
a5.set_xticks([0,1.5,3])
a5.set_yticks([0,1.5,3])
a5.set_xticklabels(['0','1.5','3'])
a5.set_yticklabels(['0','1.5','3'])


a6 = f.add_subplot(2,4,6)

a6.plot(rain_unfavourable_ASCAT[1],rain_favourable_ASCAT[1],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a6.plot(rain_unfavourable_SMAP[1],rain_favourable_SMAP[1],color='blue',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a6.get_xlim(), a6.get_ylim()]), np.max([a6.get_xlim(), a6.get_ylim()]),]

a6.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a6.set_aspect(0.9)
#a6.set_title('Ind',loc='left',weight='bold',pad=-14)
#a6.set_ylabel(r'favourable rain$_{tot}$')
#a6.set_xlabel(r'unfavourable rain$_{tot}$')
a6.set_xlim(lims)
a6.set_ylim(lims)
a6.set_xticks([0,1.5,3])
a6.set_yticks([0,2,4])
a6.set_xticklabels(['0','1.5','3'])


a7 = f.add_subplot(2,4,7)

a7.plot(rain_unfavourable_ASCAT[2],rain_favourable_ASCAT[2],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a7.plot(rain_unfavourable_SMAP[2],rain_favourable_SMAP[2],color='blue',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a7.get_xlim(), a7.get_ylim()]), np.max([a7.get_xlim(), a7.get_ylim()]),]

a7.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a7.set_aspect(0.9)
#a7.set_title('SAf',loc='left',weight='bold',pad=-14)
#a7.set_ylabel(r'favourable rain$_{tot}$')
#a7.set_xlabel(r'unfavourable rain$_{tot}$')
a7.set_xlim(lims)
a7.set_ylim(lims)
a7.set_xticks([0,1.5,3])
a7.set_yticks([0,1.5,3])
a7.set_xticklabels(['0','1.5','3'])
a7.set_yticklabels(['0','1.5','3'])


a8 = f.add_subplot(2,4,8)

a8.plot(rain_unfavourable_ASCAT[3],rain_favourable_ASCAT[3],color='grey',alpha=0.5,linestyle='-',marker='.',label='ASCAT')
a8.plot(rain_unfavourable_SMAP[3],rain_favourable_SMAP[3],color='blue',linestyle='-',marker='.',label='SMAP')

lims = [np.min([a8.get_xlim(), a8.get_ylim()]), np.max([a8.get_xlim(), a8.get_ylim()]),]

a8.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a8.set_aspect(0.9)
#a8.set_title('SAm',loc='left',weight='bold')
#a8.set_ylabel(r'favourable rain$_{tot}$')
#a8.set_xlabel(r'unfavourable rain$_{tot}$')
a8.set_xlim(lims)
a8.set_ylim(lims)

a8.set_xticks([0,2.5,5])
a8.set_yticks([0,2.5,5])
a8.set_xticklabels(['0','2.5','5'])
a8.set_yticklabels(['0','2.5','5'])

a8.legend(loc='upper right', bbox_to_anchor=(2.1, 1))

plt.subplots_adjust(wspace=0.4, hspace=0)

plt.savefig('figure3a.jpeg',dpi=1000,bbox_inches='tight',pad_inches=0.1)



