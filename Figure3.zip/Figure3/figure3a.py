###################################
#Import
###################################

import sys
import numpy as np
from netCDF4 import Dataset
import scipy.ndimage.interpolation as inter
from scipy.interpolate import griddata
import numpy.ma as ma
import matplotlib.pyplot as plt
from matplotlib import cm
plt.switch_backend('agg')
import copy
from scipy.spatial.qhull import QhullError
from scipy import stats
import matplotlib.gridspec as gridspec

###################################################

regions = ['WAf', 'Ind', 'SAf', 'SAm']

area_favourable = []
rain_favourable = []
area_unfavourable = []
rain_unfavourable = []

for region in regions:
	data = Dataset(region+'_PF1_char_dist.nc')
	areaF = data['area_F_percentiles'][:]
	areaU = data['area_U_percentiles'][:]
	rainF = data['rain_tot_F_percentiles'][:]
	rainU = data['rain_tot_U_percentiles'][:]
	area_favourable.append(areaF)
        area_unfavourable.append(areaU)
	rain_favourable.append(rainF)
	rain_unfavourable.append(rainU)

###########################################################

f=plt.figure()
a1 = f.add_subplot(2,2,1)

a1.plot(area_unfavourable[0],area_favourable[0],color='r',linestyle='-',marker='.',label='area')

lims = [np.min([a1.get_xlim(), a1.get_ylim()]), np.max([a1.get_xlim(), a1.get_ylim()]),]

a1.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

a1b  = a1.twinx().twiny()

a1b.plot(rain_unfavourable[0],rain_favourable[0],color='grey',linestyle='-',marker='.',label='rain')

limsb = [np.min([a1b.get_xlim(), a1b.get_ylim()]), np.max([a1b.get_xlim(), a1b.get_ylim()]),]

a1b.plot(limsb, limsb, 'k-', linewidth=0.7,zorder=0)

plt.legend(loc='lower right')

#a1.set_aspect(0.8)
a1.set_title('WAf',loc='left',weight='bold',pad=-14)
a1.set_xlim(lims)
a1.set_ylim(lims)
a1.set_xlabel(r'U Area x10$^{3}$ [km$^{2}$]')
a1.set_ylabel(r'F Area x10$^{3}$ [km$^{2}$]')
a1b.set_xlabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
#a1b.set_ylabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')

a2 = f.add_subplot(2,2,2)

a2.plot(area_unfavourable[1],area_favourable[1],color='r',linestyle='-',marker='.',label='area')

lims = [np.min([a2.get_xlim(), a2.get_ylim()]), np.max([a2.get_xlim(), a2.get_ylim()]),]

a2.plot(lims, lims, 'k-', linewidth=0.7,zorder=0)

plt.legend(loc='lower right')

a2b  = a2.twinx().twiny()

a2b.plot(rain_unfavourable[1],rain_favourable[1],color='grey',linestyle='-',marker='.')

limsb = [np.min([a2b.get_xlim(), a2b.get_ylim()]), np.max([a2b.get_xlim(), a2b.get_ylim()]),]

a2b.plot(limsb, limsb, 'k-', linewidth=0.7,zorder=0)

a2.set_title('Ind',loc='left',weight='bold',pad=-14)
a2.set_xlabel(r'U Area x10$^{3}$ [km$^{2}$]')
#a2.set_ylabel(r'F Area x10$^{3}$ [km$^{2}$]')
a2b.set_xlabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
#a2b.set_ylabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
a2.set_xlim(lims)
a2.set_ylim(lims)

a3 = f.add_subplot(2,2,3)

a3.plot(area_unfavourable[2],area_favourable[2],color='r',linestyle='-',marker='.')

lims = [np.min([a3.get_xlim(), a3.get_ylim()]), np.max([a3.get_xlim(), a3.get_ylim()]),]

a3.plot(lims, lims, 'k-', linewidth=0.8,zorder=0)

a3b  = a3.twinx().twiny()

a3b.plot(rain_unfavourable[2],rain_favourable[2],color='grey',linestyle='-',marker='.')

limsb = [np.min([a3b.get_xlim(), a3b.get_ylim()]), np.max([a3b.get_xlim(), a3b.get_ylim()]),]

a3b.plot(limsb, limsb, 'k-', linewidth=0.7,zorder=0)

a3.set_title('SAf',loc='left',weight='bold',pad=-14)
a3.set_xlabel(r'U Area x10$^{3}$ [km$^{2}$]')
#a3.set_ylabel(r'F Area x10$^{3}$ [km$^{2}$]')
a3b.set_xlabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
#a3b.set_ylabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
a3.set_xlim(lims)
a3.set_ylim(lims)

a4 = f.add_subplot(2,2,4)

a4.plot(area_unfavourable[3],area_favourable[3],color='r',linestyle='-',marker='.')

lims = [np.min([a4.get_xlim(), a4.get_ylim()]), np.max([a4.get_xlim(), a4.get_ylim()]),]

a4.plot(lims, lims, 'k-', linewidth=0.8,zorder=0)

a4b  = a4.twinx().twiny()

a4b.plot(rain_unfavourable[3],rain_favourable[3],color='grey',linestyle='-',marker='.')

limsb = [np.min([a4b.get_xlim(), a4b.get_ylim()]), np.max([a4b.get_xlim(), a4b.get_ylim()]),]

a4b.plot(limsb, limsb, 'k-', linewidth=0.7,zorder=0)

a4.set_title('SAm',loc='left',weight='bold',pad=-14)
a4.set_xlabel(r'U Area x10$^{3}$ [km$^{2}$]')
#a4.set_ylabel(r'F Area x10$^{3}$ [km$^{2}$]')
a4b.set_xlabel(r'F rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
#a4b.set_ylabel(r'U rain$_{tot}$ x10$^{3}$ [mm km$^{2}$ hr$^{-1}$]')
a4.set_xlim(lims)
a4.set_ylim(lims)

plt.subplots_adjust(wspace=1.0, hspace=0.6)

plt.savefig('figure3a.jpeg',dpi=1000)

