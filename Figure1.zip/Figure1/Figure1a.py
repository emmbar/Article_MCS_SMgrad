###################################
#Import
###################################

import sys
import numpy as np
import cartopy
import cartopy.crs as ccrs
import matplotlib.pyplot as plt
from matplotlib import cm
from netCDF4 import Dataset
from scipy.stats import gaussian_kde
plt.switch_backend('agg')

##################################################################

####################################

regionsN = ['WAf','Ind','Chi','USA']
regionsS = ['SAf','SAm','Aus']

####################################

data_winds = Dataset('globalwinds.nc')

lon = data_winds['longitude'][:]
lat = data_winds['latitude'][:]

lon = lon - 180.0

lon, lat = np.meshgrid(lon,lat)

def season_mean(var,hemisphere):
	if hemisphere == 'Southern':
		months = [11,12,1,2,3]
	elif hemisphere == 'Northern':
                months = [5,6,7,8,9]

	winds = np.zeros((721,1440))

	for i in months:
		dat = data_winds[var][i,:,:]
		winds += dat

	winds_mean = winds / 5.0

	return winds_mean

uSHem = season_mean('u','Southern')
vSHem = season_mean('v','Southern')
uNHem = season_mean('u','Northern')
vNHem = season_mean('v','Northern')

box_WAfx = [-18,-18,25,25,-18]
box_WAfy = [4,25,25,4,4]

box_Indx = [70,70,90,90,70]
box_Indy = [5,30,30,5,5]

box_Chix = [105,105,125,125,105]
box_Chiy = [25,40,40,25,25]

box_Ausx = [120,120,140,140,120]
box_Ausy = [-23,-11,-11,-23,-23]

box_SAmx = [-68,-68,-47,-47,-68]
box_SAmy = [-40,-20,-20,-40,-40]

box_SAfx = [20,20,35,35,20]
box_SAfy = [-35,-15,-15,-35,-35]

box_USAx = [-100,-100,-90,-90,-100]
box_USAy = [32,47,47,32,32]


############################################

f=plt.figure()
a1 = f.add_subplot(211,projection=ccrs.PlateCarree())
Nx, Ny = [], []
for region in regionsN:
        with open(region+'_stormlist.txt') as fd:
                for line in fd:
                        data = line.strip().split()
                        locx = float(data[0])
                        locy = float(data[1])
                        Nx.append(locx)
                        Ny.append(locy)
Nx, Ny = np.array(Nx), np.array(Ny)
Nxy = np.vstack([Nx,Ny])
try:
        Nz = gaussian_kde(Nxy)(Nxy)
except ValueError:
        pass
N_idx = Nz.argsort()
Nx2, Ny2, Nz2 = Nx[N_idx], Ny[N_idx],Nz[N_idx]
Nz2 = Nz2*100000.0
q1 = plt.quiver(lon, lat, uNHem, vNHem,regrid_shape=20,scale=400,transform=ccrs.PlateCarree())
cons = plt.scatter(Nx2,Ny2,c=Nz2,vmin=1,vmax=100,marker='.',s=0.1)
plt.plot(box_Indx,box_Indy,'r-')
plt.plot(box_WAfx,box_WAfy,'r-')
plt.plot(box_SAfx,box_SAfy,'r-')
plt.plot(box_Chix,box_Chiy,'r-')
plt.plot(box_SAmx,box_SAmy,'r-')
plt.plot(box_Ausx,box_Ausy,'r-')
plt.plot(box_USAx,box_USAy,'r-')
a1.coastlines()
a1.grid()
a1.set_yticks([-50,-25,0,25,50])
a1.set_xticks([-130,-65,0,65,130])
a1.set_xticklabels([])
a1.set_ylim(-50,50)
a1.set_xlim(-130,155)

a2 = f.add_subplot(212,projection=ccrs.PlateCarree())

Sx, Sy = [], []
for region in regionsS:
        with open(region+'_stormlist.txt') as fd:
                for line in fd:
                        data = line.strip().split()
                        locx = float(data[0])
                        locy = float(data[1])
                        Sx.append(locx)
                        Sy.append(locy)
Sx, Sy = np.array(Sx), np.array(Sy)
Sxy = np.vstack([Sx,Sy])
try:
        Sz = gaussian_kde(Sxy)(Sxy)
except ValueError:
        pass
S_idx = Sz.argsort()
Sx2, Sy2, Sz2 = Sx[S_idx], Sy[S_idx],Sz[S_idx]
Sz2 = Sz2 *50000.0
q1 = plt.quiver(lon, lat, uSHem, vSHem,regrid_shape=20,scale=450,transform=ccrs.PlateCarree())
cons2 = plt.scatter(Sx2,Sy2,c=Sz2,vmin=1,vmax=100,marker='.',s=0.1)
plt.plot(box_Indx,box_Indy,'r-')
plt.plot(box_WAfx,box_WAfy,'r-')
plt.plot(box_SAfx,box_SAfy,'r-')
plt.plot(box_Chix,box_Chiy,'r-')
plt.plot(box_SAmx,box_SAmy,'r-')
plt.plot(box_Ausx,box_Ausy,'r-')
plt.plot(box_USAx,box_USAy,'r-')
a2.coastlines()
a2.grid()
a2.set_yticks([-50,-25,0,25,50])
a2.set_xticks([-130,-65,0,65,130])
a2.set_ylim(-50,50)
a2.set_xlim(-130,155)

caxs = f.add_axes([0.9, 0.35, 0.01, 0.4])

cb1 = plt.colorbar(cons,cax=caxs)
cb1.set_label('Number Density')

plt.savefig('Figure1a.jpeg',dpi=1000)

