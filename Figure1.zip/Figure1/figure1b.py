
###################################

import sys
import numpy as np
import matplotlib.pyplot as plt
from netCDF4 import Dataset
from scipy import stats
plt.switch_backend('agg')
import matplotlib.gridspec as gridspec

#######################################
regions = [('USA','r'),('Chi','orange'),('Ind','y'),('WAf','g'),('SAm','b'),('SAf','m'),('Aus','k')]
#######################################
f=plt.figure(constrained_layout=True)
spec = gridspec.GridSpec(ncols=2, nrows=2, figure=f)
a4 = f.add_subplot(spec[0,0])

for item in regions:
	reg,col = item[0],item[1]

	data = Dataset(reg+'_scatter.nc')
	tgrad =  data['Tgrad']
	tgrad_line = np.linspace(np.mean(tgrad)-0.3,np.mean(tgrad)+0.3,10)
	shear = data['shear']
	tgrad_clim =  data['Tgrad_clim']
	shear_clim = data['shear_clim']

	resT = stats.linregress(tgrad, shear)
	rT = round(resT.rvalue,1)

	plt.scatter(np.average(tgrad),np.average(shear),marker='x',c=col,label='r='+str(rT)+'**')
	plt.scatter(np.average(tgrad_clim),np.average(shear_clim),marker='o',c=col)
	plt.plot(tgrad_line, resT.intercept + resT.slope*tgrad_line,ls='--',lw=1,c='k')

a4.legend(bbox_to_anchor=(1.0, 0.9),fontsize=10)
a4.set_xlabel('Poleward T grad [K/deg]')
a4.set_ylabel(r'Zonal shear [m/s]')
a4.tick_params(axis='both', which='major', labelsize=10)

a4.axhline(linewidth=0.5, color='grey')
a4.axvline(linewidth=0.5, color='grey')

a5 = f.add_subplot(spec[1,0])

for item in regions:
	reg,col = item[0],item[1]

	data = Dataset(reg+'_scatter.nc')
	SMgrad = data['SMgrad']
	SMgrad_line = np.linspace(np.mean(SMgrad)-0.01,np.mean(SMgrad)+0.01,10)
	shear = data['shear']
	SMgrad_clim = data['SMgrad_clim']
	shear_clim = data['shear_clim']

	resSM = stats.linregress(SMgrad, shear)
	rSM = round(resSM.rvalue,1)

	plt.scatter(np.average(SMgrad),np.average(shear),marker='x',c=col,label='r='+str(rSM)+'**')
	plt.scatter(np.average(SMgrad_clim),np.average(shear_clim),marker='o',c=col)
	plt.plot(SMgrad_line, resSM.intercept + resSM.slope*SMgrad_line,ls='--',lw=1,c='k')

a5.set_xlabel('Poleward SM grad [m3/m3/deg]')
a5.set_ylabel(r'Zonal shear [m/s]')
a5.legend(bbox_to_anchor=(1.0, 1.0),fontsize=10)
a5.tick_params(axis='both', which='major', labelsize=10)

a5.axhline(linewidth=0.5, color='grey')
a5.axvline(linewidth=0.5, color='grey')

plt.savefig('testfigure1b.jpeg',dpi=1000)


