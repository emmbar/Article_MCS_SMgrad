
###################################

import sys
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm
plt.switch_backend('agg')
import scipy.stats as st
from netCDF4 import Dataset

###############################################


regions = ['WAf','Ind','Chi','USA','SAm','SAf','Aus']

area_tot = np.empty((7,5))
rain_lo_tot = np.empty((7,5))
rain_mi_tot = np.empty((7,5))
rain_hi_tot = np.empty((7,5))
rainpa_tot = np.empty((7,5))

j = -1

for region in regions:

	j += 1

	data = Dataset(region+'_shear_relation_norm.nc')

	area = data['area'][:]
	rain_lo = data['rain_tot_low'][:]
	rain_mi = data['rain_tot_mod'][:]
	rain_hi = data['rain_tot_high'][:]
	rainpa = data['rain_tot_PUA'][:]

	area_tot[j,:] = area
	rain_lo_tot[j,:] = rain_lo
	rain_mi_tot[j,:] = rain_mi
	rain_hi_tot[j,:] = rain_hi
	rainpa_tot[j,:] = rainpa 

area_R = np.average(area_tot,axis=0)
rain_loR = np.average(rain_lo_tot,axis=0)
rain_miR = np.average(rain_mi_tot,axis=0)
rain_hiR = np.average(rain_hi_tot,axis=0)
rainpa_tot_R = np.average(rainpa_tot,axis=0)

err = np.zeros((5))
errpa = np.zeros((5))
errlow = np.zeros((5))
errmid = np.zeros((5))
errhigh = np.zeros((5))

for i in range(0,5):

        lims = st.t.interval(alpha=0.95, df=len(area_tot[:,i])-1, loc=np.mean(area_tot[:,i]), scale=st.sem(area_tot[:,i]))
        men = np.average(area_tot[:,i])
        diff = men - lims[0]
        err[i] = diff

        lims = st.t.interval(alpha=0.95, df=len(rain_lo_tot[:,i])-1, loc=np.percentile(rain_lo_tot[:,i],95), scale=st.sem(rain_lo_tot[:,i]))
        men = np.percentile(rain_lo_tot[:,i],95)
        diff = men - lims[0]
        errlow[i] = diff

        lims = st.t.interval(alpha=0.95, df=len(rain_mi_tot[:,i])-1, loc=np.percentile(rain_mi_tot[:,i],95), scale=st.sem(rain_mi_tot[:,i]))
        men = np.percentile(rain_mi_tot[:,i],95)
        diff = men - lims[0]
        errmid[i] = diff

        lims = st.t.interval(alpha=0.95, df=len(rain_hi_tot[:,i])-1, loc=np.percentile(rain_hi_tot[:,i],95), scale=st.sem(rain_hi_tot[:,i]))
        men = np.percentile(rain_hi_tot[:,i],95)
        diff = men - lims[0]
        errhigh[i] = diff

        lims = st.t.interval(alpha=0.95, df=len(rainpa_tot[:,i])-1, loc=np.mean(rainpa_tot[:,i]), scale=st.sem(rainpa_tot[:,i]))
        men = np.mean(rainpa_tot[:,i])
        diff = men - lims[0]
        errpa[i] = diff

bins = np.array([1,2,3,4,5])

#################################################

f=plt.figure()

a1 = f.add_subplot(231)

plt.errorbar(bins,area_R,yerr=err,ecolor='k',mfc='k',mec='k',marker='o')

a1.set_ylabel(r'Area [normalized]',size='x-small')
a1.set_xlabel(r'shear bins',size='x-small')

a1.tick_params(axis='both', which='major', labelsize=6)

a2 = f.add_subplot(232)

plt.errorbar(bins+0.1,rain_loR,yerr=errlow,ecolor='r',mfc='r',mec='r',marker='o',label='low TCW')
plt.errorbar(bins,rain_miR,yerr=errmid,ecolor='y',mfc='y',mec='y',marker='o',label='intermediate TCW')
plt.errorbar(bins-0.1,rain_hiR,yerr=errhigh,ecolor='b',mfc='b',mec='b',marker='o',label='high TCW')

plt.legend(loc='upper right', bbox_to_anchor=(1.0, 1.4),fontsize='8')

a2.set_ylabel(r'rain$_{tot}$ [normalized]',size='x-small')
a2.set_xlabel(r'shear bins',size='x-small')

a2.tick_params(axis='both', which='major', labelsize=6)

a3 = f.add_subplot(233)

plt.errorbar(bins,rainpa_tot_R,yerr=errpa,ecolor='k',mfc='k',mec='k',marker='o')

a3.set_ylabel(r'rain$_{tot}$ PUA [mm km$^{2}$ hr$^{-1}$ / km$^{2}$]',size='x-small')
a3.set_xlabel(r'shear bins',size='x-small')

a3.tick_params(axis='both', which='major', labelsize=6)

plt.subplots_adjust(wspace=0.5)

plt.savefig('figure2.jpeg',dpi=1000,bbox_inches='tight',pad_inches=0.1)

